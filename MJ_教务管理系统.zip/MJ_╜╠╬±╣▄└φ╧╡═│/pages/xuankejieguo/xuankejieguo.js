const app=getApp()

Page({

  /**
   * 页面的初始数据
   */
  data: {
    select: false,
    tihuoWay: '2018-2019学年第一学期',
    xkjg:''
  },

  find:function(){
    var that = this;
    wx.cloud.init();
    wx.cloud.callFunction({
      name: 'xuankejieguo',
      data: {
        _id: app.globalData.user_id,
        xueqi: this.data.tihuoWay
      },
      complete: res => {
        console.log(res)
        that.setData({
          xkjg: res.result.data[0].result
        })

      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    

  },
  bindShowMsg() {
    this.setData({
      select: !this.data.select
    })
  },
  mySelect(e) {
    var name = e.currentTarget.dataset.name
    this.setData({
      tihuoWay: name,
      select: false
    })
    

  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})