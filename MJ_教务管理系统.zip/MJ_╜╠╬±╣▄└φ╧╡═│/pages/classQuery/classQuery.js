var app = getApp()
Page({
  data: {
    classStr:'',
    marginleft: '52',
    help_status: false,
    ClassDetail: "",

  },
  onLoad: function(options) {
    var that = this;
    wx.cloud.init();
    wx.cloud.callFunction({
      name: 'kebiao',
      data: {
        _id: app.globalData.user_id,
      },
      complete: res => {
        console.log(res)
        that.setData({
          classStr: res.result.data[0].courses
        })
      }
    })
   

    // wx.showToast({
    //   title: "loading",
    //   icon: "loading",
    //   duration: 15000
    // })
    console.log(this.data.classStr)
    
  },
  onPullDownRefresh: function() {
    var that = this;
    that.onLoad();
    wx.stopPullDownRefresh();
    wx.showToast({
      title: "刷新完成",
      icon: "succeed",
      duration: 2000
    })
  },
  tapHelp: function(e) {
    if (e.target.id == 'help') {
      this.hideHelp();
    }
  },
  showHelp: function(e) {
    this.setData({
      'help_status': true,
      'ClassDetail': e.currentTarget.dataset.set
    });
  },
  hideHelp: function(e) {
    this.setData({
      'help_status': false
    });
  },
  /**
   * 长按复制到粘贴板的处理函数
   */
  copyIt: function(event) {
    wx.setClipboardData({
      data: event.target.id
    })
    wx.showToast({
      title: '已复制到粘贴版',
      icon: 'none',
      duration: 1000
    });
  },
})