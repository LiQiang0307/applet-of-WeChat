Page({
  data: {
    //查询结果
    cardInfo:[],
    timeArea:[],
    flag: 0
  },

  isCardID: function (sId) {
    if(sId.length!=0){
    return true;}
    else{
      return false;
    }
  },

  //提交事件
  formSubmit: function (e) {

    var cardId = e.detail.value.cardId;
    var me = this;
    if (cardId.length == 0) {
      me.setData({
        flag: 0
      })
      return;
    }
    var res = this.isCardID(cardId);

    if (res === true) {

      wx.request({
        url: "http://api.ip138.com/express/info/?no=" + cardId+"&token=79aa65ceef254098da911bbde7195a17",

        header: {
          'Content-Type': 'text/plain;charset=utf-8;'
        },
        success: function (res) {
          console.log(res);
          if (res.data.ret == "ok") {
            console.log("查询成功");

            me.setData({
              cardInfo: {
                company:res.data.company,
                
              },
              timeArea:res.data.data.traces,
              flag:1
             
            })
            
                // for (var i = 0, max =res.data.data.traces.length;i<max;i++){
                //   me.setData({
                //     timeArea:{
                //       time: res.data.data.traces[],
                //       area: res.data.data.traces[i]

                //     }
                //   })
                // };
          }
           else {
            wx.showToast({
              title: res.data.ret,
              icon: 'success',
              duration: 2000
            });
          }
        }
      });
    } else {
      wx.showToast({
        title: "查询失败",
        icon: 'success',
        duration: 2000
      });
    }


  }


})