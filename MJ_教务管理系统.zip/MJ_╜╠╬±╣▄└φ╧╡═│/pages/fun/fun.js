const app = getApp();
Page({
  data: {

    id:'',
   
    parentItem: [
      {
        itemTiele: "信息查询",
        imgUrls: [
          "cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/成绩查询.png",
          "cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/课表查询.png",
          "cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/空教室查询.png",
          "cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/校历查询.png"
        ],
        texts: [
          "成绩查询",
          "课表查询",
          "空教室查询",
          "校历查询",
        ]
      },
      {
        itemTiele: "重修选课",
        imgUrls: [
          "cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/报名.png",
          "cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/报名结果查看.png",
          "cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/选课.png",
          "cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/选课结果.png"
          
        ],
        texts: [
          "重修报名",
          "重修结果",
          "在线选课",
          "选课结果",
        ]
      },
     
      {

        itemTiele:"生活助手",
        imgUrls:[
          'cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/社区.png',
          'cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/a38.png',
          'cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/天气查询.png',
          'cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/快递查询.png',
          'cloud://jilin-agricultural-4ab42c.6a69-jilin-agricultural-4ab42c/funImage/科学计算.png',

         

        ],
        texts:[

            "通知公告",
            '身份证查询',
            "天气查询",
            "快递查询",
            "科学计算"


        ]

        



      }

    ]
  },

  goTools: function (event) {
    var to = event.target.dataset.sel
    var to_str = this.isToUrl[to];
    console.log(to);
    wx.navigateTo({
      url: '../' + to_str + '/' + to_str 
    })
    console.log(app.globalData.user_id+"!!!")
  

  },


  isToUrl: {
    "0-0": "achievement",
    "0-1": "classQuery",
    "0-2": "kjs",
    "0-3":"xiaoli",
    "1-0": "chongxiu",
    "1-1": "chongxiujieguo",
    "1-2": "xuanke",
    "1-3":"xuankejieguo",
    "2-0": "text",
    "2-1": "card",
    "2-2": "main",
    "2-3": "kuaidi",
    "2-4":"jisuan",
  },

  onLoad: function (options) {
    
  app.globalData.user_id=options.id;
  this.setData({

    id: app.globalData.user_id
  })     
  
  },
 
  onShareAppMessage: function () {
    return {
      title: '智慧农苑',
      desc: '吉林农业科技学院教务管理系统！！',
      path: '/pages/index/index'
    }
  }

})
