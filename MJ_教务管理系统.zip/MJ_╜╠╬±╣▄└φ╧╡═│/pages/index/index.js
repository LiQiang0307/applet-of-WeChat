//index.js
//获取应用实例
const app = getApp()



Page({

  data: {
    phone: '',
    password: '',
    user:[],
    swiperCurrent: 0,

    indicatorDots: true,

    autoplay: true,

    interval: 3000,

    duration: 800,

    circular: true,

    indicatoractivecolor:'black',

    imgUrls: [

      // '../image/a.jpg',
      // '../image/b.jpg',
      'http://www.jlnku.com/images/17/06/09/1a0s62xbjw/g.jpg',
      'http://www.jlnku.com/images/17/06/09/1a0s62xbjw/a.jpg',
      'http://www.jlnku.com/images/17/06/09/1a0s62xbjw/20170425145134.jpg',
      // '../image/c.jpg'

    ],

    links: [

      '../user/user',

      '../user/user',

      '../user/user'

    ]



  },

  //轮播图的切换事件

  swiperChange: function(e) {

    this.setData({

      swiperCurrent: e.detail.current

    })

  },

  //点击指示点切换

  chuangEvent: function(e) {

    this.setData({

      swiperCurrent: e.currentTarget.id

    })

  },

  //点击图片触发事件

  swipclick: function(e) {

    console.log(this.data.swiperCurrent);

    wx.switchTab({

      url: this.data.links[this.data.swiperCurrent]

    })

  },


    // 获取输入账号
    phoneInput:function (e) {
    this.setData({
      phone: e.detail.value
    })
  },
  // 获取输入密码
  passwordInput : function (e) {
    this.setData({
      password: e.detail.value
    })
  },
  // 登录
  login: function () {
    if (this.data.phone.length == 0 || this.data.password.length == 0) {
      wx.showToast({
        title: '输入不能为空',
        icon: 'loading',
        duration: 2000
      })
    } else{
      // 这里修改成跳转的页面
      wx.cloud.init();
      wx.cloud.callFunction({
        name: 'login',
        data: {
          username: this.data.phone,
          password: this.data.password,
        },
        complete: res => {
          console.log(res)
          // console.log(res.result.data[0]._id)
          if(res.result.data.length==1){
            wx.navigateTo({
              url: '../fun/fun?id='+res.result.data[0].id
            });
            wx.showToast({
              title: '登录成功',
              icon: 'success',
              duration: 2000
            })
          }
          else {
            wx.showToast({
              title: '账号或密码错误',
              icon: 'success',
              duration: 2000
            })
          }
        },
      })
    
       
          }
         
          
        },
  onShareAppMessage: function () {
    return {
      title: '智慧农苑',
      desc: '吉林农业科技学院教务管理系统！！',
      path: '/pages/index/index'
    }
  }

      })
      
      

