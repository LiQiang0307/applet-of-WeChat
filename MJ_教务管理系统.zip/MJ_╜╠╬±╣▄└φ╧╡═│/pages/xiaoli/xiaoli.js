const app = getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {},

calendar:function(){
  wx.navigateTo({
    url: '../calendar/calendar'
  })

  
},

  download:function() {
    // sent data change to view
    wx.downloadFile({
      url: 'https://6a69-jilin-agricultural-4ab42c-1253219771.tcb.qcloud.la/吉林农业科技学院2018-2019（二）学期校历说明.xlsx?sign=c56f6d131181d0506e57e622a573ef74&t=1550802280',
      success: function (res) {
        var filePath = res.tempFilePath
        wx.openDocument({
          filePath: filePath,
          success: function (res) {
            console.log('打开文档成功')
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})