const app=getApp()


Page({

  /**
   * 页面的初始数据
   */
  data: {
    username:'',
    grade:'',
    flag:0,
    flag2:0,
    flag3:0,
    flag4:0,
    flag5:0
   

    
  },



  open:function(){
      if(this.data.flag==0){

        this.setData({
          flag:1
        })
      }else{
        this.setData({
          flag: 0
        })
      }
    console.log(this.data.grade)
  },
  open2: function () {
    if (this.data.flag2 == 0) {

      this.setData({
        flag2: 1
      })
    } else {
      this.setData({
        flag2: 0
      })
    }

  },
  open3: function () {
    if (this.data.flag3 == 0) {

      this.setData({
        flag3: 1
      })
    } else {
      this.setData({
        flag3: 0
      })
    }

  },
  open4: function () {
    if (this.data.flag4 == 0) {

      this.setData({
        flag4: 1
      })
    } else {
      this.setData({
        flag4: 0
      })
    }

  },
  open5: function () {
    if (this.data.flag5 == 0) {

      this.setData({
        flag5: 1
      })
    } else {
      this.setData({
        flag5: 0
      })
    }

  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function () {
    var that=this;
    wx.cloud.init();
    wx.cloud.callFunction({
      name: 'search',
      data: {
        _id: app.globalData.user_id,
      },
      complete: res =>{
        console.log(res)
       that.setData({
         grade: res.result.data[0].nianfen
       })
         
        app.globalData.grade=res.result.data[0] 
         
        wx.setNavigationBarTitle({
          title: app.globalData.grade.name + '的成绩'
        })
      }   
  })
console.log(this.data.grade)
 

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
    var page = this
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
    
})