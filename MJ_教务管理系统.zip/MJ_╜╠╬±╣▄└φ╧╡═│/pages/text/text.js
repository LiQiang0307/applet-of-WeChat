//text.js
var util = require('../../utils/util.js')
var root = getApp()

Page({
  data: {
    data: '',
    modalHidden: true,
    modalContent: ''
  },
  onLoad: function () {
    var that = this;
    wx.cloud.init();
    wx.cloud.callFunction({
      name: 'inform',
      complete: res => {
        console.log(res)
        that.setData({
          data: res.result.data[0].info
        })
      }
    })
  },
  modalTap: function (e) {
    var self = this
    console.log(e.currentTarget.dataset)
    console.log(this.data)
    // console.log(self.data[Number(e.currentTarget.dataset.index)])
    this.setData({
      modalContent: self.data.data[Number(e.currentTarget.dataset.index)],
      modalHidden: false
    })
  },
  modalHide: function(e) {
    this.setData({
      modalHidden: true
    })
  }
  // contentLimit: function(content) {
  //   return content.substr(20)
  // }
})
