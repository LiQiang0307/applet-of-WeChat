//初始化数据

function tabbarinit() {

  return [

    {
      "current": 0,

      "pagePath": "../../pages/main/main",

      "iconPath": "../../pages/assets/img/home-s.png",

      "selectedIconPath": "../../pages/assets/img/home.png",

      "text": "主页"

    },

    {

      "current": 0,

      "pagePath": "../../pages/life/life",

      "iconPath": "../../pages/assets/img/life-s.png",

      "selectedIconPath": "../../pages/assets/img/life.png",

      "text": "生活"



    },

    {

      "current": 0,

      "pagePath": "../../pages/future/future",

      // "iconPath": "../../pages/assets/img/future.png",
      "iconPath": "../../pages/future/img/future-s.png",
      "selectedIconPath": "../../pages/assets/img/future.png",

      "text": "未来"

    },

   

  ]



}

//tabbar 主入口

function tabbarmain(bindName = "tabdata", id, target) {

  var that = target;

  var bindData = {};

  var otabbar = tabbarinit();

  otabbar[id]['iconPath'] = otabbar[id]['selectedIconPath']//换当前的icon

  otabbar[id]['current'] = 1;

  bindData[bindName] = otabbar

  that.setData({ bindData });

}



module.exports = {

  tabbar: tabbarmain

}